/**
 * apiService.js
 *
 * Este arquivo centraliza todas as chamadas de API (fetch) da aplicação.
 * Ele expõe um objeto global `window.apiService` que os outros scripts
 * (telaLogin.js, telaProfessor.js, etc.) podem usar.
 */
(function() {
    'use strict';

    const API_URL = 'http://localhost:3000/api';

    /**
     * Helper PRIVADO para chamadas de API públicas (que não exigem token).
     * Usado para login e recuperação de senha.
     */
    async function fetchPublico(url, options = {}) {
        try {
            const response = await fetch(url, options);
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.error || 'Erro desconhecido.');
            }
            return data;
        } catch (error) {
            console.error('Erro no fetchPublico:', error);
            throw error; // Re-lança o erro para o script que chamou
        }
    }

    /**
     * Helper PRIVADO para chamadas de API autenticadas (que exigem token).
     */
    async function fetchComToken(url, options = {}) {
        const token = localStorage.getItem('token');

        // Se o token não existir, desloga o usuário imediatamente
        if (!token) {
            console.warn("Token não encontrado no localStorage. Redirecionando para login.");
            localStorage.clear();
            window.location.href = 'telaLogin.html';
            throw new Error('Token não encontrado.');
        }

        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
            ...options.headers,
        };

        try {
            const response = await fetch(url, { ...options, headers });

            // Se o token for inválido ou expirado, o backend retornará 401 ou 403
            if (response.status === 401 || response.status === 403) {
                console.warn("Token inválido ou expirado (status " + response.status + "). Deslogando.");
                localStorage.clear();
                window.location.href = 'telaLogin.html';
                throw new Error('Token inválido ou expirado.');
            }
            
            // CORREÇÃO: Verificar o 204 (No Content) ANTES de tentar ler o .json()
            // Respostas DELETE ou PUT de sucesso podem retornar 204
            if (response.status === 204) {
                return null; // Retorna null para indicar sucesso sem conteúdo
            }

            // Se não for 204, verificamos se a resposta foi OK (200-299)
            if (!response.ok) {
                // Se não foi OK, AGORA podemos ler o .json() de erro
                const errorData = await response.json();
                throw new Error(errorData.error || `Erro HTTP: ${response.status}`);
            }
            
            // Se foi OK e não foi 204, lemos o .json() de sucesso
            return response.json();

        } catch (error) {
            console.error(`Erro no fetchComToken para ${url}:`, error);
            throw error; // Re-lança o erro
        }
    }

    /**
     * Objeto global de API
     * Contém todas as funções que as páginas podem chamar.
     */
    window.apiService = {

        // --- Rotas Públicas ---
        login: (email, password, tipo_usuario) => {
            return fetchPublico(`${API_URL}/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password, tipo_usuario })
            });
        },
        recuperarSenha: (email) => {
             return fetchPublico(`${API_URL}/recuperar-senha`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email })
            });
        },
        definirNovaSenha: (email, novaSenha) => {
            return fetchPublico(`${API_URL}/nova-senha`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, novaSenha })
            });
        },

        // --- Rotas Comuns (Autenticadas) ---
        getLaboratorios: () => {
            return fetchComToken(`${API_URL}/laboratorios`);
        },
        getMateriais: () => {
             return fetchComToken(`${API_URL}/materiais`);
        },
        createMaterial: (itemData) => {
            return fetchComToken(`${API_URL}/materiais`, {
                method: 'POST',
                body: JSON.stringify(itemData)
            });
        },
        // ATUALIZADO: Adicionada função para deletar material
        deleteMaterial: (id) => {
            return fetchComToken(`${API_URL}/materiais/${id}`, {
                method: 'DELETE'
            });
        },
        getHistorico: () => {
            return fetchComToken(`${API_URL}/agendamentos/historico`);
        },

        // --- Rotas de Professor ---
        getAgendamentosProfessor: () => {
            return fetchComToken(`${API_URL}/professor/agendamentos`);
        },
        createAgendamento: (agendamentoData) => {
            return fetchComToken(`${API_URL}/professor/agendamentos`, {
                method: 'POST',
                body: JSON.stringify(agendamentoData)
            });
        },
        cancelarAgendamentoProfessor: (id) => {
             return fetchComToken(`${API_URL}/professor/agendamentos/${id}/cancelar`, {
                method: 'PUT'
            });
        },
        getKits: () => {
            return fetchComToken(`${API_URL}/professor/kits`);
        },
        createKit: (kitData) => {
            return fetchComToken(`${API_URL}/professor/kits`, {
                method: 'POST',
                body: JSON.stringify(kitData)
            });
        },
        updateKit: (id, kitData) => {
            return fetchComToken(`${API_URL}/professor/kits/${id}`, {
                method: 'PUT',
                body: JSON.stringify(kitData)
            });
        },
        deleteKit: (id) => {
            return fetchComToken(`${API_URL}/professor/kits/${id}`, {
                method: 'DELETE'
            });
        },
        
        // --- Rotas de Técnico/Admin ---
        getAgendamentosPendentes: () => {
            return fetchComToken(`${API_URL}/tecnico/agendamentos/pendentes`);
        },
        updateStatusAgendamento: (id, status) => {
             return fetchComToken(`${API_URL}/tecnico/agendamentos/${id}/status`, {
                method: 'PUT',
                body: JSON.stringify({ status: status })
            });
        },

        // --- Rotas de Admin ---
        getAgendamentosAdmin: () => {
            return fetchComToken(`${API_URL}/admin/agendamentos`);
        },
        getUsuarios: () => {
            return fetchComToken(`${API_URL}/admin/usuarios`);
        },
        createUsuario: (userData) => {
            return fetchComToken(`${API_URL}/admin/usuarios`, {
                method: 'POST',
                body: JSON.stringify(userData)
            });
        },
        deleteUsuario: (id) => {
            return fetchComToken(`${API_URL}/admin/usuarios/${id}`, {
                method: 'DELETE'
            });
        },
    };

})(); // Fim da IIFE

