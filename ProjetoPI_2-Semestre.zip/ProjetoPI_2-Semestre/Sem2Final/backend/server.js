const express = require('express');
const path = require('path');
const cors = require('cors');
const jwt = require('jsonwebtoken'); // Para autenticação
const bcrypt = require('bcryptjs'); // Para hash de senhas
const pool = require('./db'); // Importa o pool de conexão MySQL

const app = express();
const port = 3000;
const JWT_SECRET = 'seu-segredo-jwt-super-secreto'; // Mude isso para algo seguro
const SALT_ROUNDS = 10; // Custo do hash

// Middlewares
app.use(cors());
app.use(express.json());

// Servir arquivos estáticos do frontend
app.use(express.static(path.join(__dirname, '../frontend')));

// Rota raiz para entregar a tela de login
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend', 'telaLogin.html'));
});

// --- Middleware de Autenticação ---
const autenticarToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Formato "Bearer TOKEN"

  if (token == null) {
    console.warn("Acesso negado: Token não fornecido.");
    return res.sendStatus(401); // Não autorizado (sem token)
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      console.warn("Acesso negado: Token inválido ou expirado.");
      return res.sendStatus(403); // Proibido (token inválido)
    }
    req.user = user; // Adiciona os dados do usuário (id, nome, tipo_usuario) ao request
    next(); // Continua para a rota
  });
};

// --- FUNÇÕES AUXILIARES DE ESTOQUE (NOVAS) ---

/**
 * Debita os itens de um kit do estoque.
 * Lança um erro se o estoque for insuficiente.
 */
async function debitarEstoque(connection, fk_kit, id_agendamento, id_usuario_professor, id_usuario_tecnico) {
    if (!fk_kit) return; // Se não há kit, não há o que debitar.
    
    // 1. Buscar os itens do kit E o estoque atual (com FOR UPDATE para travar as linhas)
    const [itensDoKit] = await connection.query(
        `SELECT 
            km.fk_material, 
            km.quantidade_no_kit, 
            m.quantidade as estoque_atual,
            m.nome as nome_material
         FROM kit_materiais km
         JOIN materiais m ON km.fk_material = m.id_material
         WHERE km.fk_kit = ?
         FOR UPDATE`, // Trava as linhas de material
        [fk_kit]
    );

    // 2. Verificar se há estoque para TODOS os itens
    for (const item of itensDoKit) {
        if (item.quantidade_no_kit > item.estoque_atual) {
            throw new Error(`Estoque insuficiente para: ${item.nome_material}. Pedido: ${item.quantidade_no_kit}, Disponível: ${item.estoque_atual}`);
        }
    }

    // 3. Se passou na verificação, debitar o estoque e registrar a movimentação
    const updatesEstoque = [];
    for (const item of itensDoKit) {
        // Debita o estoque
        updatesEstoque.push(
            connection.query(
                'UPDATE materiais SET quantidade = quantidade - ? WHERE id_material = ?',
                [item.quantidade_no_kit, item.fk_material]
            )
        );
        // Registra na tabela de movimentações (Técnico que deu a saída)
        updatesEstoque.push(
            connection.query(
                `INSERT INTO movimentacoes (fk_material, fk_usuario, tipo_movimentacao, quantidade, observacoes)
                 VALUES (?, ?, 'saida', ?, ?)`,
                [item.fk_material, id_usuario_tecnico, item.quantidade_no_kit, `Saída para agendamento ID: ${id_agendamento} (Prof. ID: ${id_usuario_professor})`]
            )
        );
    }
    await Promise.all(updatesEstoque);
}

/**
 * Retorna os itens de um kit ao estoque (estorno).
 */
async function retornarEstoque(connection, fk_kit, id_agendamento, id_usuario_acao) {
    if (!fk_kit) return; // Se não há kit, não há o que retornar.

    // 1. Buscar os itens do kit
    const [itensDoKit] = await connection.query(
        `SELECT km.fk_material, km.quantidade_no_kit
         FROM kit_materiais km
         WHERE km.fk_kit = ?
         FOR UPDATE`, // Trava as linhas de material
        [fk_kit]
    );

    // 2. Retornar o estoque e registrar a movimentação
    const updatesEstoque = [];
    for (const item of itensDoKit) {
        // Retorna o estoque (soma)
        updatesEstoque.push(
            connection.query(
                'UPDATE materiais SET quantidade = quantidade + ? WHERE id_material = ?',
                [item.quantidade_no_kit, item.fk_material]
            )
        );
        // Registra na tabela de movimentações (Quem cancelou)
        updatesEstoque.push(
            connection.query(
                `INSERT INTO movimentacoes (fk_material, fk_usuario, tipo_movimentacao, quantidade, observacoes)
                 VALUES (?, ?, 'entrada', ?, ?)`, // Tipo 'entrada'
                [item.fk_material, id_usuario_acao, item.quantidade_no_kit, `Devolução por cancelamento do agendamento ID: ${id_agendamento}`]
            )
        );
    }
    await Promise.all(updatesEstoque);
}
// --- FIM DAS FUNÇÕES AUXILIARES ---


// --- ROTAS PÚBLICAS (Login / Recuperação de Senha) ---

// [LOGIN]
app.post('/api/login', async (req, res) => {
  const { email, password, tipo_usuario } = req.body;

  if (!email || !password || !tipo_usuario) {
    return res.status(400).json({ error: 'E-mail, senha e tipo de usuário são obrigatórios.' });
  }

  try {
    const [rows] = await pool.query(
      'SELECT * FROM usuarios WHERE email = ? AND tipo_usuario = ?',
      [email, tipo_usuario]
    );

    if (rows.length === 0) {
      return res.status(401).json({ error: 'Credenciais inválidas. Verifique seu e-mail, senha e tipo de usuário.' });
    }
    
    const user = rows[0];
    let senhaCorreta = false;

    try {
      // Detecta se o campo já está em formato bcrypt (começa com $2)
      const pareceHashBcrypt = typeof user.senha_hash === 'string' && user.senha_hash.startsWith('$2');

      if (pareceHashBcrypt) {
        senhaCorreta = await bcrypt.compare(password, user.senha_hash);
      } else {
        // Migração automática: se a senha no banco está em texto puro e bate com a informada
        if (password === user.senha_hash) {
          const novoHash = await bcrypt.hash(password, SALT_ROUNDS);
          await pool.query('UPDATE usuarios SET senha_hash = ? WHERE id_usuario = ?', [novoHash, user.id_usuario]);
          senhaCorreta = true;
        } else {
          senhaCorreta = false;
        }
      }
    } catch (e) {
      console.error('Erro ao validar/migrar senha:', e);
      return res.status(500).json({ error: 'Erro interno na validação de credenciais.' });
    }

    if (senhaCorreta) {
      const payload = { 
        id: user.id_usuario, 
        nome: user.nome, 
        tipo_usuario: user.tipo_usuario 
      };
      const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '8h' });

      let redirectTo = '';
      switch (user.tipo_usuario) {
        case 'admin': redirectTo = 'telaAdmin.html'; break;
        case 'professor': redirectTo = 'telaProfessor.html'; break;
        case 'tecnico': redirectTo = 'telaTecnico.html'; break;
        default: redirectTo = 'telaLogin.html';
      }
      
      res.json({ 
        success: true, 
        redirectTo: redirectTo, 
        token: token, 
        userId: user.id_usuario,
        userName: user.nome,
        userType: user.tipo_usuario
      });

    } else {
      res.status(401).json({ error: 'Credenciais inválidas. Verifique seu e-mail, senha e tipo de usuário.' });
    }
  } catch (err) {
    console.error('Erro na rota /api/login:', err);
    res.status(500).json({ error: 'Erro interno do servidor.' });
  }
});

// [ESQUECEU SENHA] - Passo 1: Verificar E-mail
app.post('/api/recuperar-senha', async (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'E-mail é obrigatório.' });
  }
  try {
    const [rows] = await pool.query(
      'SELECT id_usuario FROM usuarios WHERE email = ?',
      [email]
    );
    if (rows.length > 0) {
      res.json({ success: true, message: 'E-mail encontrado.' });
    } else {
      res.status(404).json({ error: 'E-mail não cadastrado no sistema.' });
    }
  } catch (err) {
    console.error('Erro na rota /api/recuperar-senha:', err);
    res.status(500).json({ error: 'Erro interno do servidor.' });
  }
});

// [ESQUECEU SENHA] - Passo 2: Definir Nova Senha
app.post('/api/nova-senha', async (req, res) => {
  const { email, novaSenha } = req.body;
  if (!email || !novaSenha) {
    return res.status(400).json({ error: 'E-mail e nova senha são obrigatórios.' });
  }
  try {
    const hash = await bcrypt.hash(novaSenha, SALT_ROUNDS);
    const [result] = await pool.query(
      'UPDATE usuarios SET senha_hash = ? WHERE email = ?',
      [hash, email]
    );
    if (result.affectedRows > 0) {
      res.json({ success: true, message: 'Senha alterada com sucesso!' });
    } else {
      res.status(404).json({ error: 'E-mail não encontrado.' });
    }
  } catch (err) {
    console.error('Erro na rota /api/nova-senha:', err);
    res.status(500).json({ error: 'Erro interno do servidor.' });
  }
});

// [LABORATORIOS]
app.get('/api/laboratorios', autenticarToken, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT *, id_laboratorio as id FROM laboratorios ORDER BY nome_laboratorio');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});


// --- ROTAS PROTEGIDAS (Exigem autenticação) ---

// [PROFESSOR] Obter agendamentos do professor logado
app.get('/api/professor/agendamentos', autenticarToken, async (req, res) => {
  if (req.user.tipo_usuario !== 'professor') {
    return res.status(403).json({ error: 'Acesso negado.' });
  }
  try {
    const [rows] = await pool.query(
      `SELECT a.*, l.nome_laboratorio, k.nome_kit
       FROM agendamentos a
       LEFT JOIN laboratorios l ON a.fk_laboratorio = l.id_laboratorio
       LEFT JOIN kits k ON a.fk_kit = k.id_kit
       WHERE a.fk_usuario = ?
       ORDER BY a.data_hora_inicio DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// [PROFESSOR] Criar novo agendamento
app.post('/api/professor/agendamentos', autenticarToken, async (req, res) => {
  if (req.user.tipo_usuario !== 'professor') {
    return res.status(403).json({ error: 'Acesso negado.' });
  }
  
  const {
    data_hora_inicio, data_hora_fim,
    fk_laboratorio, fk_kit, observacoes
  } = req.body;
  
  if (!data_hora_inicio || !data_hora_fim || !fk_laboratorio) {
      return res.status(400).json({ error: 'Data, horário e laboratório são obrigatórios.' });
  }
  
  try {
    const [result] = await pool.query(
      `INSERT INTO agendamentos 
        (fk_usuario, data_hora_inicio, data_hora_fim, fk_laboratorio, fk_kit, observacoes, status_agendamento)
       VALUES (?, ?, ?, ?, ?, ?, 'pendente')`,
      [req.user.id, data_hora_inicio, data_hora_fim, fk_laboratorio, fk_kit, observacoes]
    );
    const [novoAgendamento] = await pool.query('SELECT * FROM agendamentos WHERE id_agendamento = ?', [result.insertId]);
    res.status(201).json(novoAgendamento[0]);

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// [PROFESSOR] Cancelar um agendamento - MODIFICADO (Lógica de Estorno)
app.put('/api/professor/agendamentos/:id/cancelar', autenticarToken, async (req, res) => {
    if (req.user.tipo_usuario !== 'professor' && req.user.tipo_usuario !== 'admin') {
        return res.status(403).json({ error: 'Acesso negado.' });
    }
    const { id } = req.params;
    const id_usuario_acao = req.user.id; // Quem está cancelando

    const connection = await pool.getConnection();

    try {
        await connection.beginTransaction();
        
        // 1. Busca o agendamento e trava a linha
        const [rows] = await connection.query(
            'SELECT fk_kit, fk_usuario, status_agendamento FROM agendamentos WHERE id_agendamento = ? FOR UPDATE',
            [id]
        );

        if (rows.length === 0) {
            throw new Error('Agendamento não encontrado.');
        }

        const agendamento = rows[0];

        // 2. Verifica permissão (Professor só pode cancelar o seu, admin pode cancelar qualquer um)
        if (req.user.tipo_usuario === 'professor' && agendamento.fk_usuario !== id_usuario_acao) {
             throw new Error('Você não tem permissão para cancelar este agendamento.');
        }
        
        // 3. LÓGICA DE ESTORNO: Se o agendamento estava 'confirmado', devolve o estoque
        if (agendamento.status_agendamento === 'confirmado') {
            await retornarEstoque(connection, agendamento.fk_kit, id, id_usuario_acao);
        }
        
        // 4. Atualiza o status do agendamento para 'cancelado'
        const [result] = await connection.query(
            'UPDATE agendamentos SET status_agendamento = ? WHERE id_agendamento = ?',
            ['cancelado', id]
        );

        await connection.commit();
        
        if (result.affectedRows > 0) {
            res.json({ success: true, message: 'Agendamento cancelado.' });
        } else {
            // Este else não deve ser atingido por causa da checagem inicial
            res.status(404).json({ error: 'Agendamento não encontrado.' });
        }
    } catch (err) {
        await connection.rollback();
        console.error(err);
        res.status(500).json({ error: err.message });
    } finally {
        connection.release();
    }
});


// [PROFESSOR] Obter materiais que podem compor um kit
app.get('/api/professor/materiais-para-kit', autenticarToken, async (req, res) => {
  if (req.user.tipo_usuario !== 'professor') {
    return res.status(403).json({ error: 'Acesso negado.' });
  }
  try {
    const [rows] = await pool.query(
      `SELECT id_material as id, nome, unidade, quantidade 
       FROM materiais 
       WHERE tipo_material IN ('vidraria', 'reagente', 'consumivel')
       ORDER BY nome`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// [PROFESSOR] Obter kits
app.get('/api/professor/kits', autenticarToken, async (req, res) => {
  if (req.user.tipo_usuario !== 'professor' && req.user.tipo_usuario !== 'admin') {
    return res.status(403).json({ error: 'Acesso negado.' });
  }
  try {
    const [rows] = await pool.query(
        `SELECT *, id_kit as id FROM kits ORDER BY nome_kit`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// [PROFESSOR] Criar novo kit
app.post('/api/professor/kits', autenticarToken, async (req, res) => {
  if (req.user.tipo_usuario !== 'professor') {
    return res.status(403).json({ error: 'Acesso negado.' });
  }
  
  const { nome_kit, itens, descricao_kit } = req.body; 
  
  if (!nome_kit || !itens || itens.length === 0) {
      return res.status(400).json({ error: 'Nome do kit e pelo menos um item são obrigatórios.'});
  }

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction(); 

    const desc = descricao_kit || `Kit ${nome_kit} com ${itens.length} tipo(s) de item.`;
    const [resultKit] = await connection.query(
      `INSERT INTO kits (nome_kit, descricao_kit) VALUES (?, ?)`,
      [nome_kit, desc]
    );
    const novoKitId = resultKit.insertId;

    const insertsItens = itens.map(item => {
        return connection.query(
            'INSERT INTO kit_materiais (fk_kit, fk_material, quantidade_no_kit) VALUES (?, ?, ?)',
            [novoKitId, item.id_material, item.quantidade]
        );
    });
    await Promise.all(insertsItens); 

    await connection.commit(); 
    
    const [novoKit] = await connection.query('SELECT *, id_kit as id FROM kits WHERE id_kit = ?', [novoKitId]);
    res.status(201).json(novoKit[0]);

  } catch (err) {
    await connection.rollback(); 
    console.error(err);
     if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Um kit com este nome já existe.' });
    }
    res.status(500).json({ error: err.message });
  } finally {
      connection.release(); 
  }
});

// [PROFESSOR] Atualizar kit
app.put('/api/professor/kits/:id', autenticarToken, async (req, res) => {
    if (req.user.tipo_usuario !== 'professor') {
        return res.status(403).json({ error: 'Acesso negado.' });
    }
    const { id } = req.params;
    const { nome_kit, itens, descricao_kit } = req.body; 

    if (!nome_kit || !itens || itens.length === 0) {
      return res.status(400).json({ error: 'Nome do kit e pelo menos um item são obrigatórios.'});
    }
    
    const connection = await pool.getConnection();

    try {
        await connection.beginTransaction();

        const desc = descricao_kit || `Kit ${nome_kit} com ${itens.length} tipo(s) de item.`;
        await connection.query(
            'UPDATE kits SET nome_kit = ?, descricao_kit = ? WHERE id_kit = ?',
            [nome_kit, desc, id]
        );
        
        await connection.query('DELETE FROM kit_materiais WHERE fk_kit = ?', [id]);
        
        const insertsItens = itens.map(item => {
            return connection.query(
                'INSERT INTO kit_materiais (fk_kit, fk_material, quantidade_no_kit) VALUES (?, ?, ?)',
                [id, item.id_material, item.quantidade] 
            );
        });
        await Promise.all(insertsItens);

        await connection.commit();
        res.json({ success: true, message: 'Kit atualizado.' });

    } catch (err) {
        await connection.rollback();
        console.error(err);
         if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ error: 'Um kit com este nome já existe.' });
        }
        res.status(500).json({ error: err.message });
    } finally {
        connection.release();
    }
});

// [PROFESSOR] Excluir kit
app.delete('/api/professor/kits/:id', autenticarToken, async (req, res) => {
    if (req.user.tipo_usuario !== 'professor' && req.user.tipo_usuario !== 'admin') {
        return res.status(403).json({ error: 'Acesso negado.' });
    }
    const { id } = req.params;
    try {
        const [result] = await pool.query(
            'DELETE FROM kits WHERE id_kit = ?',
            [id]
        );
        
        if (result.affectedRows > 0) {
            res.sendStatus(204); 
        } else {
            res.status(404).json({ error: 'Kit não encontrado.' });
        }
    } catch (err) {
        console.error(err);
        if (err.code === 'ER_ROW_IS_REFERENCED_2') {
             return res.status(409).json({ error: 'Este kit não pode ser excluído pois está sendo usado em agendamentos.' });
        }
        res.status(500).json({ error: err.message });
    }
});


// --- ROTAS DO ADMIN ---

// [ADMIN] Obter todos os usuários
app.get('/api/admin/usuarios', autenticarToken, async (req, res) => {
  if (req.user.tipo_usuario !== 'admin') {
    return res.status(403).json({ error: 'Acesso negado.' });
  }
  try {
    const [rows] = await pool.query('SELECT id_usuario as id, nome, email, tipo_usuario FROM usuarios ORDER BY nome');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// [ADMIN] Criar novo usuário
app.post('/api/admin/usuarios', autenticarToken, async (req, res) => {
  if (req.user.tipo_usuario !== 'admin') {
    return res.status(403).json({ error: 'Acesso negado.' });
  }
  const { nome, email, tipo_usuario, senha } = req.body;
  if (!nome || !email || !tipo_usuario || !senha) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios.'});
  }
  try {
    const hash = await bcrypt.hash(senha, SALT_ROUNDS);

    const [result] = await pool.query(
      `INSERT INTO usuarios (nome, email, tipo_usuario, senha_hash) VALUES (?, ?, ?, ?)`,
      [nome, email, tipo_usuario, hash]
    );
    res.status(201).json({ id: result.insertId, nome, email, tipo_usuario });
  } catch (err) {
    console.error('Erro ao criar usuário:', err);
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Este e-mail já está cadastrado.' });
    }
    res.status(500).json({ error: err.message });
  }
});

// [ADMIN] Excluir usuário
app.delete('/api/admin/usuarios/:id', autenticarToken, async (req, res) => {
    if (req.user.tipo_usuario !== 'admin') {
        return res.status(403).json({ error: 'Acesso negado.' });
    }
    const { id } = req.params;
    if (req.user.id == id) {
        return res.status(400).json({ error: 'Você não pode excluir a si mesmo.'});
    }
    try {
        const [result] = await pool.query('DELETE FROM usuarios WHERE id_usuario = ?', [id]);
        if (result.affectedRows > 0) {
            res.sendStatus(204);
        } else {
            res.status(404).json({ error: 'Usuário não encontrado.' });
        }
    } catch (err) {
        console.error('Erro ao excluir usuário:', err);
        if (err.code === 'ER_ROW_IS_REFERENCED_2') {
             return res.status(409).json({ error: 'Este usuário não pode ser excluído pois possui agendamentos ou movimentações registradas.' });
        }
        res.status(500).json({ error: err.message });
    }
});


// [ADMIN/TECNICO] Obter todos os materiais (Estoque)
app.get('/api/materiais', autenticarToken, async (req, res) => {
    if (req.user.tipo_usuario !== 'admin' && req.user.tipo_usuario !== 'tecnico') {
        return res.status(403).json({ error: 'Acesso negado.' });
    }
    try {
        const [rows] = await pool.query('SELECT *, id_material as id FROM materiais ORDER BY nome');
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// [ADMIN/TECNICO] Criar novo material (Estoque)
app.post('/api/materiais', autenticarToken, async (req, res) => {
    if (req.user.tipo_usuario !== 'admin' && req.user.tipo_usuario !== 'tecnico') {
        return res.status(403).json({ error: 'Acesso negado.' });
    }
    
    const { nome, descricao, localizacao, tipoUnidade, valor } = req.body;

    if (!nome || !tipoUnidade || !valor) {
         return res.status(400).json({ error: 'Nome, Tipo e Valor/Quantidade são obrigatórios.'});
    }

    let tipo_material = 'consumivel';
    let unidade = 'UN';

    if (tipoUnidade === 'peso') {
        tipo_material = 'reagente';
        unidade = 'g';
    } else if (tipoUnidade === 'litros') {
        tipo_material = 'reagente';
        unidade = 'ml';
    } else if (tipoUnidade === 'unidade') {
        tipo_material = 'vidraria'; 
        unidade = 'UN';
    }
    
    try {
        const [result] = await pool.query(
            `INSERT INTO materiais (nome, descricao, localizacao, tipo_material, quantidade, unidade, status) 
             VALUES (?, ?, ?, ?, ?, ?, 'disponivel')`,
            [nome, descricao, localizacao, tipo_material, valor, unidade]
        );
        const [novoMaterial] = await pool.query('SELECT *, id_material as id FROM materiais WHERE id_material = ?', [result.insertId]);
        res.status(201).json(novoMaterial[0]);
    } catch (err) {
        console.error('Erro ao criar material:', err);
        res.status(500).json({ error: err.message });
    }
});

// [ADMIN/TECNICO] Excluir material (Estoque)
app.delete('/api/materiais/:id', autenticarToken, async (req, res) => {
    if (req.user.tipo_usuario !== 'admin' && req.user.tipo_usuario !== 'tecnico') {
        return res.status(403).json({ error: 'Acesso negado.' });
    }
    const { id } = req.params;
    try {
        const [result] = await pool.query('DELETE FROM materiais WHERE id_material = ?', [id]);
        if (result.affectedRows > 0) {
            res.sendStatus(204); 
        } else {
            res.status(404).json({ error: 'Material não encontrado.' });
        }
    } catch (err) {
        console.error('Erro ao excluir material:', err);
        if (err.code === 'ER_ROW_IS_REFERENCED_2') {
             return res.status(409).json({ error: 'Este material não pode ser excluído pois está associado a um kit ou agendamento.' });
        }
        res.status(500).json({ error: err.message });
    }
});

// [ADMIN] Obter todos os agendamentos (para visão geral)
app.get('/api/admin/agendamentos', autenticarToken, async (req, res) => {
    if (req.user.tipo_usuario !== 'admin') {
        return res.status(403).json({ error: 'Acesso negado.' });
    }
    try {
        const [rows] = await pool.query(
          `SELECT 
             a.*, 
             l.nome_laboratorio, 
             k.nome_kit,
             u.nome as nome_professor
           FROM agendamentos a
           LEFT JOIN laboratorios l ON a.fk_laboratorio = l.id_laboratorio
           LEFT JOIN kits k ON a.fk_kit = k.id_kit
           LEFT JOIN usuarios u ON a.fk_usuario = u.id_usuario
           ORDER BY a.data_hora_inicio DESC`
        );
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});


// --- ROTAS DO TÉCNICO ---

// [TECNICO] Obter agendamentos pendentes
app.get('/api/tecnico/agendamentos/pendentes', autenticarToken, async (req, res) => {
  if (req.user.tipo_usuario !== 'tecnico' && req.user.tipo_usuario !== 'admin') {
    return res.status(403).json({ error: 'Acesso negado.' });
  }
  try {
    const [rows] = await pool.query(
      `SELECT 
         a.*, 
         l.nome_laboratorio, 
         k.nome_kit,
         u.nome as nome_professor,
         GROUP_CONCAT(CONCAT(km.quantidade_no_kit, 'x ', m.nome, ' (', m.unidade, ')') SEPARATOR '\n') as descricao_kit
       FROM agendamentos a
       LEFT JOIN laboratorios l ON a.fk_laboratorio = l.id_laboratorio
       LEFT JOIN usuarios u ON a.fk_usuario = u.id_usuario
       LEFT JOIN kits k ON a.fk_kit = k.id_kit
       LEFT JOIN kit_materiais km ON k.id_kit = km.fk_kit
       LEFT JOIN materiais m ON km.fk_material = m.id_material
       WHERE a.status_agendamento = 'pendente'
       GROUP BY a.id_agendamento 
       ORDER BY a.data_hora_inicio ASC`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// [TECNICO] Atualizar status de um agendamento - MODIFICADO (Lógica de Débito/Estorno)
app.put('/api/tecnico/agendamentos/:id/status', autenticarToken, async (req, res) => {
    if (req.user.tipo_usuario !== 'tecnico' && req.user.tipo_usuario !== 'admin') {
        return res.status(403).json({ error: 'Acesso negado.' });
    }
    const { id } = req.params;
    const { status } = req.body; // 'confirmado' ou 'cancelado'
    const id_usuario_tecnico = req.user.id;

    if (!status || (status !== 'confirmado' && status !== 'cancelado')) {
        return res.status(400).json({ error: "Status inválido." });
    }

    const connection = await pool.getConnection();

    try {
        await connection.beginTransaction();

        // 1. Busca o agendamento e trava a linha
        const [rows] = await connection.query(
            'SELECT fk_kit, fk_usuario, status_agendamento FROM agendamentos WHERE id_agendamento = ? FOR UPDATE',
            [id]
        );
        
        if (rows.length === 0) {
             throw new Error('Agendamento não encontrado.');
        }
        
        const agendamento = rows[0];
        const statusAnterior = agendamento.status_agendamento;

        // 2. Lógica de Estoque
        
        // CASO A: Aprovando um agendamento pendente
        if (status === 'confirmado' && statusAnterior === 'pendente') {
            await debitarEstoque(connection, agendamento.fk_kit, id, agendamento.fk_usuario, id_usuario_tecnico);
        }
        
        // CASO B: Cancelando um agendamento que JÁ ESTAVA confirmado (Estorno)
        else if (status === 'cancelado' && statusAnterior === 'confirmado') {
            await retornarEstoque(connection, agendamento.fk_kit, id, id_usuario_tecnico);
        }
        
        // Outros casos (ex: confirmar algo já confirmado, cancelar algo pendente) não mexem no estoque.

        // 3. Atualiza o status do agendamento
        const [result] = await connection.query(
            'UPDATE agendamentos SET status_agendamento = ? WHERE id_agendamento = ?',
            [status, id]
        );

        await connection.commit(); // Confirma a transação

        if (result.affectedRows > 0) {
            res.json({ success: true, message: `Agendamento ${status}.` });
        } else {
            res.status(404).json({ error: 'Agendamento não encontrado.' });
        }

    } catch (err) {
        await connection.rollback(); // Desfaz tudo se der erro (ex: estoque insuficiente)
        console.error('Erro ao atualizar status:', err);
        res.status(500).json({ error: err.message || 'Erro interno do servidor.' });
    } finally {
        connection.release();
    }
});


// [TECNICO/ADMIN] Obter histórico de agendamentos
app.get('/api/agendamentos/historico', autenticarToken, async (req, res) => {
    if (req.user.tipo_usuario !== 'tecnico' && req.user.tipo_usuario !== 'admin') {
        return res.status(403).json({ error: 'Acesso negado.' });
    }
    try {
        const [rows] = await pool.query(
          `SELECT 
             a.*, 
             l.nome_laboratorio, 
             u.nome as nome_professor
           FROM agendamentos a
           LEFT JOIN laboratorios l ON a.fk_laboratorio = l.id_laboratorio
           LEFT JOIN usuarios u ON a.fk_usuario = u.id_usuario
           WHERE a.status_agendamento != 'pendente'
           ORDER BY a.data_hora_inicio DESC`
        );
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});


// Inicia o servidor
app.listen(port, () => {
  console.log(`Backend rodando em http://localhost:${port}`);
});